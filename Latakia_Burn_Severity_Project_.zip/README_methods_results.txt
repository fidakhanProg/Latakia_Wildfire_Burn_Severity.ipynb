LATakia wildfire burn-severity regression project

Target:
- dNBR (continuous regression target)

Predictors:
- NDVI_pre, NDMI_pre, NBR_pre, elevation_m, slope_deg,
  northness, eastness, landcover_pre,
  NDVI_pre_mean60m, NDVI_pre_sd60m

Excluded from predictors:
- longitude, latitude, sample_id, fold
- fire_temp_C, fire_wind_ms, fire_vpd_kPa,
  antecedent_rain_mm, in_fire

Validation:
- Four-fold spatial outer cross-validation using the provided fold assignments.
- For each outer fold, hyperparameter tuning used only the other three folds,
  with inner validation grouped by their saved spatial fold assignments.
- Preprocessing and model fitting were performed within the training pipeline.
- Performance is reported from pooled out-of-fold predictions.

Models compared:
- Random Forest regression
- Extra Trees regression

Best model by pooled out-of-fold RMSE:
- Extra Trees
- R2 = 0.3388
- RMSE = 0.1608 dNBR
- MAE = 0.1272 dNBR

Interpretation:
- NDVI_pre had the largest mean held-out permutation importance.
- Importance and response plots describe model behaviour and predictive
  relationships; they do not establish causation.
- Performance varied by spatial fold; Fold 4 was the most difficult
  held-out area for both tested models.
- ALE plots were generated from a final explanatory model fitted to all
  samples and are not independent validation results.

Software:
- scikit-learn 1.6.1
- See the notebook for the complete executed code, settings, and random seeds.

Caution:
- This package does not include a fitted model artifact unless one is
  explicitly saved and added.
- Full-area raster prediction requires predictor rasters aligned in CRS,
  resolution, extent, and pixel grid.
